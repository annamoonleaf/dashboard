// Application data
const appData = {
    "lipetsk_pyramid": {
        "ages": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80],
        "female_2024": [21254, 31051, 31846, 29020, 25174, 26316, 36354, 48563, 44951, 43079, 40245, 39461, 49047, 47903, 38383, 20518, 32147],
        "female_2034": [16819.761386838545, 17742.084094240558, 21224.975791144712, 31005.0859082479, 31742.05884620506, 28878.874743133932, 25010.37465030634, 26052.080213399042, 35769.941505302064, 47356.214472111106, 43369.18046780344, 41048.60143839573, 37531.854069698216, 35464.480577897705, 41486.174711831325, 36384.61617049156, 23367.802557121242],
        "male_2024": [-22845, -32466, -33367, -29159, -25200, -27031, -35794, -46878, -42892, -39185, -35089, -32406, -36775, -31899, -21386, -9577, -9004],
        "male_2034": [-17643.387995597302, -18604.080620502642, -22783.884898267705, -32359.036316613514, -33095.485673010428, -28652.738332041135, -24482.341499054394, -25864.027688514652, -33585.49012794793, -42910.41802695327, -38165.98343285841, -33642.83784839554, -28479.006543252628, -24121.620267122387, -24159.449813629726, -17570.789978533565, -8920.973306726331]
    },
    "lipetsk_vs_rosstat": {
        "ages": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80],
        "our_female": [16819.761386838545, 17742.084094240558, 21224.975791144712, 31005.0859082479, 31742.05884620506, 28878.874743133932, 25010.37465030634, 26052.080213399042, 35769.941505302064, 47356.214472111106, 43369.18046780344, 41048.60143839573, 37531.854069698216, 35464.480577897705, 41486.174711831325, 36384.61617049156, 23367.802557121242],
        "our_male": [-17643.387995597302, -18604.080620502642, -22783.884898267705, -32359.036316613514, -33095.485673010428, -28652.738332041135, -24482.341499054394, -25864.027688514652, -33585.49012794793, -42910.41802695327, -38165.98343285841, -33642.83784839554, -28479.006543252628, -24121.620267122387, -24159.449813629726, -17570.789978533565, -8920.973306726331],
        "rosstat_female": [21923, 22756, 25422, 32355, 33490, 29086, 26939, 26736, 36235, 45294, 43677, 41861, 39004, 36807, 42444, 36248, 48170],
        "rosstat_male": [-23198, -24026, -26635, -33553, -35548, -23502, -24868, -26648, -35677, -43077, -39968, -35385, -30940, -26256, -26512, -18296, -12616]
    },
    "russia_vs_un": {
        "ages": ["0-4", "5-9", "10-14", "15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49", "50-54", "55-59", "60-64", "65-69", "70-74", "75-79", "80+"],
        "our_female": [3226915, 3383141, 3707074, 4439340, 4522736, 4048774, 3668897, 3770261, 5135535, 6256632, 5795945, 5289429, 4769350, 4378073, 4981268, 4267579, 4710492],
        "our_male": [-3409481, -3567654, -3907451, -4684839, -4824547, -4333781, -3934018, -3992354, -5252519, -6043967, -5332714, -4510971, -3852590, -3207751, -3207157, -2285309, -1842221],
        "un_female": [2958939.5, 3038859, 3414871.5, 4443570.5, 4918157, 4394107.5, 3614079.5, 3419809.5, 4768475.5, 6191861.5, 5712376, 5231445.5, 4716394, 4234392.5, 4930022, 4333279, 5121758],
        "un_male": [-3117447, -3202219, -3608315.5, -4683914.5, -5125361, -4522319.5, -3722107, -3481711.5, -4718994, -5853976.5, -5069347, -4288395.5, -3637201, -2927348.5, -2932672.5, -2118904, -1828149]
    },
    "fertility_rates": {
        "age_groups": ["15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49"],
        "rates": [11.476, 57.925, 78.367, 55.688, 30.098, 7.398, 0.164]
    },
    "mortality_rates": {
        "ages": [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85],
        "female_nlx": [498740.8, 498257.0, 498059.7, 497520.2, 496434.1, 495100.8, 493207.4, 490135.5, 485283.6, 477955.6, 468206.5, 455428.6, 436642.1, 409303.9, 369331.6, 310885.8, 224851.3, 110572.8],
        "male_nlx": [498250.5, 497585.4, 496917.6, 495946.1, 492874.1, 487335.4, 478837.7, 466296.3, 449293.2, 426830.7, 399788.2, 366461.6, 324476.9, 272778.1, 213166.1, 150253.2, 88920.3, 35878.0]
    }
};

// Global chart instances
let charts = {};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeTabs();
    initializeCharts();
    initializeControls();
});

// Tab functionality
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
            
            // Re-initialize charts for the active tab
            setTimeout(() => {
                initializeChartsForTab(targetTab);
            }, 100);
        });
    });
}

// Initialize controls
function initializeControls() {
    // Year toggle functionality
    const yearToggles = document.querySelectorAll('.year-toggle');
    yearToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            yearToggles.forEach(t => t.classList.remove('active'));
            toggle.classList.add('active');
            
            const year = toggle.getAttribute('data-year');
            updateLipetskPyramid(year);
        });
    });

    // Compare years button
    const compareBtn = document.getElementById('compareYears');
    if (compareBtn) {
        compareBtn.addEventListener('click', () => {
            updateLipetskPyramid('compare');
        });
    }
}

// Initialize all charts
function initializeCharts() {
    initializeLipetskPyramid('2024');
}

// Initialize charts for specific tab
function initializeChartsForTab(tabId) {
    switch(tabId) {
        case 'lipetsk':
            if (!charts.lipetskPyramid) {
                initializeLipetskPyramid('2024');
            }
            break;
        case 'comparison':
            initializeComparisonCharts();
            break;
        case 'russia-un':
            initializeRussiaUNCharts();
            break;
        case 'demographics':
            initializeDemographicsCharts();
            break;
    }
}

// Lipetsk pyramid chart
function initializeLipetskPyramid(year) {
    const ctx = document.getElementById('lipetskPyramid');
    if (!ctx) return;

    if (charts.lipetskPyramid) {
        charts.lipetskPyramid.destroy();
    }

    let femaleData, maleData, title;
    
    if (year === '2024') {
        femaleData = appData.lipetsk_pyramid.female_2024;
        maleData = appData.lipetsk_pyramid.male_2024;
        title = 'Популяционная пирамида Липецкой области - 2024 год';
    } else if (year === '2034') {
        femaleData = appData.lipetsk_pyramid.female_2034;
        maleData = appData.lipetsk_pyramid.male_2034;
        title = 'Популяционная пирамида Липецкой области - 2034 год (прогноз)';
    } else if (year === 'compare') {
        // Show both years for comparison
        charts.lipetskPyramid = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: appData.lipetsk_pyramid.ages.map(age => `${age}-${age+4}`),
                datasets: [
                    {
                        label: 'Мужчины 2024',
                        data: appData.lipetsk_pyramid.male_2024,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Женщины 2024',
                        data: appData.lipetsk_pyramid.female_2024,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Мужчины 2034',
                        data: appData.lipetsk_pyramid.male_2034,
                        backgroundColor: 'rgba(54, 162, 235, 0.3)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        borderDash: [5, 5]
                    },
                    {
                        label: 'Женщины 2034',
                        data: appData.lipetsk_pyramid.female_2034,
                        backgroundColor: 'rgba(255, 99, 132, 0.3)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    title: {
                        display: true,
                        text: 'Сравнение популяционных пирамид: 2024 vs 2034'
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return Math.abs(value).toLocaleString();
                            }
                        }
                    },
                    y: {
                        display: true
                    }
                }
            }
        });
        return;
    }

    charts.lipetskPyramid = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: appData.lipetsk_pyramid.ages.map(age => `${age}-${age+4}`),
            datasets: [
                {
                    label: 'Мужчины',
                    data: maleData,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Женщины',
                    data: femaleData,
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: {
                title: {
                    display: true,
                    text: title
                },
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = Math.abs(context.parsed.x);
                            return `${context.dataset.label}: ${value.toLocaleString()} чел.`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return Math.abs(value).toLocaleString();
                        }
                    }
                },
                y: {
                    display: true
                }
            }
        }
    });
}

function updateLipetskPyramid(year) {
    initializeLipetskPyramid(year);
}

// Comparison charts (Our vs Rosstat)
function initializeComparisonCharts() {
    // Our forecast chart
    const ctxOur = document.getElementById('ourForecast');
    if (ctxOur && !charts.ourForecast) {
        charts.ourForecast = new Chart(ctxOur, {
            type: 'bar',
            data: {
                labels: appData.lipetsk_vs_rosstat.ages.map(age => `${age}-${age+4}`),
                datasets: [
                    {
                        label: 'Мужчины',
                        data: appData.lipetsk_vs_rosstat.our_male,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Женщины',
                        data: appData.lipetsk_vs_rosstat.our_female,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = Math.abs(context.parsed.x);
                                return `${context.dataset.label}: ${value.toLocaleString()} чел.`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return Math.abs(value).toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }

    // Rosstat forecast chart
    const ctxRosstat = document.getElementById('rosstatForecast');
    if (ctxRosstat && !charts.rosstatForecast) {
        charts.rosstatForecast = new Chart(ctxRosstat, {
            type: 'bar',
            data: {
                labels: appData.lipetsk_vs_rosstat.ages.map(age => `${age}-${age+4}`),
                datasets: [
                    {
                        label: 'Мужчины',
                        data: appData.lipetsk_vs_rosstat.rosstat_male,
                        backgroundColor: 'rgba(75, 192, 192, 0.6)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Женщины',
                        data: appData.lipetsk_vs_rosstat.rosstat_female,
                        backgroundColor: 'rgba(153, 102, 255, 0.6)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = Math.abs(context.parsed.x);
                                return `${context.dataset.label}: ${value.toLocaleString()} чел.`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return Math.abs(value).toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
}

// Russia vs UN charts
function initializeRussiaUNCharts() {
    // Our Russia forecast
    const ctxRussiaOur = document.getElementById('russiaOur');
    if (ctxRussiaOur && !charts.russiaOur) {
        charts.russiaOur = new Chart(ctxRussiaOur, {
            type: 'bar',
            data: {
                labels: appData.russia_vs_un.ages,
                datasets: [
                    {
                        label: 'Мужчины',
                        data: appData.russia_vs_un.our_male,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Женщины',
                        data: appData.russia_vs_un.our_female,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = Math.abs(context.parsed.x);
                                return `${context.dataset.label}: ${(value/1000000).toFixed(1)} млн чел.`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return (Math.abs(value)/1000000).toFixed(1) + 'М';
                            }
                        }
                    }
                }
            }
        });
    }

    // UN forecast
    const ctxRussiaUN = document.getElementById('russiaUN');
    if (ctxRussiaUN && !charts.russiaUN) {
        charts.russiaUN = new Chart(ctxRussiaUN, {
            type: 'bar',
            data: {
                labels: appData.russia_vs_un.ages,
                datasets: [
                    {
                        label: 'Мужчины',
                        data: appData.russia_vs_un.un_male,
                        backgroundColor: 'rgba(75, 192, 192, 0.6)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Женщины',
                        data: appData.russia_vs_un.un_female,
                        backgroundColor: 'rgba(153, 102, 255, 0.6)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = Math.abs(context.parsed.x);
                                return `${context.dataset.label}: ${(value/1000000).toFixed(1)} млн чел.`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return (Math.abs(value)/1000000).toFixed(1) + 'М';
                            }
                        }
                    }
                }
            }
        });
    }
}

// Demographics charts
function initializeDemographicsCharts() {
    // Fertility rates chart
    const ctxFertility = document.getElementById('fertilityChart');
    if (ctxFertility && !charts.fertilityChart) {
        charts.fertilityChart = new Chart(ctxFertility, {
            type: 'bar',
            data: {
                labels: appData.fertility_rates.age_groups,
                datasets: [{
                    label: 'Коэффициент рождаемости',
                    data: appData.fertility_rates.rates,
                    backgroundColor: 'rgba(255, 193, 7, 0.6)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.parsed.y.toFixed(3)} на 1000 женщин`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Коэффициент рождаемости (на 1000 женщин)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Возрастные группы'
                        }
                    }
                }
            }
        });
    }

    // Mortality rates chart
    const ctxMortality = document.getElementById('mortalityChart');
    if (ctxMortality && !charts.mortalityChart) {
        charts.mortalityChart = new Chart(ctxMortality, {
            type: 'line',
            data: {
                labels: appData.mortality_rates.ages,
                datasets: [
                    {
                        label: 'Женщины',
                        data: appData.mortality_rates.female_nlx,
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.1)',
                        borderWidth: 2,
                        fill: false
                    },
                    {
                        label: 'Мужчины',
                        data: appData.mortality_rates.male_nlx,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.1)',
                        borderWidth: 2,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'nLx (число доживающих)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Возраст'
                        }
                    }
                }
            }
        });
    }
}